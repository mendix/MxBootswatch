CREATE TABLE "bootswatch$dropdownacti" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('7f2d4795-ab88-42af-8bdd-8d93c6a41230', 
'Bootswatch.DropdownActi', 
'bootswatch$dropdownacti');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20140204 10:15:10';
